import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import Link from "next/link"
import { Heart, DollarSign, Shield, Sparkles, Star, Phone, MessageCircle } from "lucide-react"
import { TestimonialsSection } from "@/components/testimonials"
import { TrustElements } from "@/components/trust-elements"

export default function HomePage() {
  const services = [
    {
      icon: Heart,
      title: "Amarres de Amor",
      description: "Rituales poderosos para unir corazones y recuperar el amor perdido",
      price: "Desde $150 USD",
      features: ["Recuperar ex pareja", "Fortalecer relaciones", "Atraer amor verdadero", "Eliminar terceras personas"],
      href: "/servicios/amarres-amor",
    },
    {
      icon: Sparkles,
      title: "Endulzamientos",
      description: "Suaviza el corazón de la persona amada creando dulzura y reconciliación",
      price: "Desde $120 USD",
      features: ["Calmar conflictos", "Generar cariño", "Facilitar reconciliación", "Mejorar comunicación"],
      href: "/servicios/endulzamientos",
    },
    {
      icon: DollarSign,
      title: "Rituales de Prosperidad",
      description: "Atrae abundancia económica y éxito financiero a tu vida",
      price: "Desde $200 USD",
      features: ["Mejorar situación económica", "Nuevas oportunidades", "Incrementar ingresos", "Eliminar bloqueos"],
      href: "/servicios/prosperidad",
    },
    {
      icon: Shield,
      title: "Protección Espiritual",
      description: "Protégete de energías negativas, envidias y ataques espirituales",
      price: "Desde $180 USD",
      features: ["Escudos energéticos", "Protección del hogar", "Neutralizar trabajos negativos", "Limpieza de aura"],
      href: "/servicios/proteccion",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-card opacity-90"></div>
        <div className="relative max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Más de 20 años de experiencia</Badge>
              <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
                <span className="text-primary">Rituales y Pactos</span>
                <br />
                <span className="text-foreground">Poderosos</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 text-pretty">
                Maestro Antonio Vasquez te ayuda a transformar tu vida con rituales ancestrales efectivos. Amarres de
                amor, prosperidad, protección espiritual y más.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button size="lg" className="bg-accent hover:bg-accent/90">
                  <Phone className="w-5 h-5 mr-2" />
                  Consulta Gratuita
                </Button>
                <Button size="lg" variant="outline">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Ver Servicios
                </Button>
              </div>
            </div>
            <div className="flex justify-center lg:justify-end">
              <div className="relative">
                <div className="absolute inset-0 bg-primary/20 rounded-full blur-3xl"></div>
                <Image
                  src="/antonio-profile.png"
                  alt="Maestro Antonio Vasquez"
                  width={400}
                  height={400}
                  className="relative rounded-2xl shadow-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
              Servicios <span className="text-primary">Esotéricos</span> Profesionales
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Técnicas ancestrales combinadas con conocimiento moderno para resolver tus problemas más profundos y
              transformar tu destino.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 border-border/50 hover:border-primary/50"
              >
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <service.icon className="w-6 h-6 text-primary" />
                    </div>
                    <Badge variant="secondary" className="text-accent">
                      {service.price}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">{service.title}</CardTitle>
                  <CardDescription className="text-muted-foreground">{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm text-muted-foreground">
                        <Star className="w-4 h-4 text-accent mr-2 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button asChild className="w-full">
                    <Link href={service.href}>Más Información</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <TestimonialsSection />

      {/* About Preview Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-accent/10 text-accent border-accent/20">Maestro Reconocido</Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">
                Conoce al <span className="text-primary">Maestro Antonio Vasquez</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-6 text-pretty">
                Con más de 20 años dedicado al arte ancestral de la brujería y los rituales esotéricos, he ayudado a
                miles de personas a transformar sus vidas y encontrar la felicidad.
              </p>
              <p className="text-muted-foreground mb-8 text-pretty">
                Mi formación multicultural abarca desde la santería afrocubana hasta rituales europeos antiguos y
                prácticas chamánicas latinoamericanas, permitiéndome desarrollar técnicas únicas y efectivas.
              </p>
              <Button asChild size="lg" variant="outline">
                <Link href="/sobre-antonio">Conocer Más Sobre Antonio</Link>
              </Button>
            </div>
            <div className="flex justify-center">
              <div className="relative">
                <Image src="/logo.png" alt="Símbolo Místico" width={300} height={300} className="opacity-80" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Elements Section */}
      <TrustElements />

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-primary/5">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">
            ¿Listo para <span className="text-primary">Transformar tu Vida</span>?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 text-pretty">
            No esperes más. Contacta al Maestro Antonio Vasquez y comienza tu camino hacia la felicidad, el amor y la
            prosperidad que mereces.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-accent hover:bg-accent/90">
              <Phone className="w-5 h-5 mr-2" />
              Consulta Inmediata
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/contacto">Solicitar Información</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
