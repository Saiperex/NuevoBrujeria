import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Heart, Sparkles, DollarSign, Shield, Zap, Flame, Star, Phone } from "lucide-react"

export default function ServiciosPage() {
  const services = [
    {
      icon: Heart,
      title: "Amarres de Amor",
      description: "Rituales poderosos diseñados para unir corazones y recuperar el amor perdido",
      price: "Desde $150 USD",
      features: [
        "Recuperar a tu ex pareja",
        "Fortalecer relaciones existentes",
        "Atraer el amor verdadero",
        "Eliminar terceras personas",
      ],
      href: "/servicios/amarres-amor",
      color: "text-red-400",
    },
    {
      icon: Sparkles,
      title: "Endulzamientos",
      description: "Rituales que suavizan el corazón de la persona amada, creando dulzura y reconciliación",
      price: "Desde $120 USD",
      features: [
        "Calmar conflictos de pareja",
        "Generar cariño y ternura",
        "Facilitar la reconciliación",
        "Mejorar la comunicación",
      ],
      href: "/servicios/endulzamientos",
      color: "text-pink-400",
    },
    {
      icon: DollarSign,
      title: "Rituales de Prosperidad",
      description: "Atrae la abundancia económica y el éxito financiero a tu vida",
      price: "Desde $200 USD",
      features: [
        "Mejorar tu situación económica",
        "Atraer nuevas oportunidades",
        "Incrementar tus ingresos",
        "Eliminar bloqueos financieros",
      ],
      href: "/servicios/prosperidad",
      color: "text-green-400",
    },
    {
      icon: Shield,
      title: "Protección Espiritual",
      description: "Protégete de energías negativas, envidias y ataques espirituales",
      price: "Desde $180 USD",
      features: [
        "Escudos energéticos personales",
        "Protección del hogar y familia",
        "Neutralización de trabajos negativos",
        "Limpieza de aura y chakras",
      ],
      href: "/servicios/proteccion",
      color: "text-blue-400",
    },
    {
      icon: Zap,
      title: "Limpiezas y Desbloqueos",
      description: "Elimina obstáculos y energías estancadas que impiden tu progreso",
      price: "Desde $160 USD",
      features: [
        "Desbloqueo de caminos cerrados",
        "Limpieza de energías negativas",
        "Apertura de nuevas oportunidades",
        "Renovación energética completa",
      ],
      href: "/servicios/limpiezas",
      color: "text-purple-400",
    },
    {
      icon: Flame,
      title: "Amarres Sexuales",
      description: "Rituales especializados para despertar la pasión y el deseo intenso",
      price: "Desde $220 USD",
      features: [
        "Despertar pasión dormida",
        "Aumentar la atracción sexual",
        "Crear conexión íntima profunda",
        "Revitalizar relaciones",
      ],
      href: "/servicios/amarres-sexuales",
      color: "text-orange-400",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Servicios Profesionales</Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
            <span className="text-primary">Servicios Esotéricos</span>
            <br />
            <span className="text-foreground">Especializados</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto text-pretty">
            Descubre el poder de los rituales ancestrales con más de 20 años de experiencia. Cada servicio está diseñado
            para transformar tu vida y resolver tus problemas más profundos.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 border-border/50 hover:border-primary/50 h-full"
              >
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <service.icon className={`w-6 h-6 ${service.color}`} />
                    </div>
                    <Badge variant="secondary" className="text-accent">
                      {service.price}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">{service.title}</CardTitle>
                  <CardDescription className="text-muted-foreground">{service.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <ul className="space-y-2 mb-6 flex-1">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start text-sm text-muted-foreground">
                        <Star className="w-4 h-4 text-accent mr-2 flex-shrink-0 mt-0.5" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button asChild className="w-full">
                    <Link href={service.href}>Ver Detalles</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-primary/5">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">
            ¿No encuentras lo que <span className="text-primary">necesitas</span>?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 text-pretty">
            Cada caso es único. Contacta al Maestro Antonio para una consulta personalizada y descubre el ritual
            perfecto para tu situación específica.
          </p>
          <Button size="lg" className="bg-accent hover:bg-accent/90">
            <Phone className="w-5 h-5 mr-2" />
            Consulta Personalizada
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  )
}
