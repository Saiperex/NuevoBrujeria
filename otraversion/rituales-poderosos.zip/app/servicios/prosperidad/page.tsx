import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Phone, CheckCircle, ArrowLeft, TrendingUp } from "lucide-react"
import Link from "next/link"

export default function ProsperidadPage() {
  const benefits = [
    "Mejorar tu situación económica actual",
    "Atraer nuevas oportunidades de negocio",
    "Incrementar tus ingresos significativamente",
    "Eliminar bloqueos financieros persistentes",
    "Abrir caminos hacia la abundancia",
    "Proteger y multiplicar tus recursos",
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Breadcrumb */}
      <div className="py-4 px-4 sm:px-6 lg:px-8 border-b border-border">
        <div className="max-w-7xl mx-auto">
          <Link href="/servicios" className="inline-flex items-center text-muted-foreground hover:text-primary">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver a Servicios
          </Link>
        </div>
      </div>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-green-500/10 text-green-400 border-green-500/20">Abundancia Garantizada</Badge>
              <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
                <span className="text-primary">Rituales de</span>
                <br />
                <span className="text-green-400">Prosperidad</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 text-pretty">
                Atrae la abundancia económica y el éxito financiero a tu vida. Estos poderosos rituales trabajan para
                abrir los caminos hacia la prosperidad que mereces.
              </p>
              <div className="flex items-center space-x-4 mb-8">
                <Badge variant="secondary" className="text-accent text-lg px-4 py-2">
                  Desde $200 USD
                </Badge>
                <div className="flex items-center text-muted-foreground">
                  <Clock className="w-4 h-4 mr-2" />
                  <span>Resultados en 15-30 días</span>
                </div>
              </div>
              <Button size="lg" className="bg-accent hover:bg-accent/90">
                <Phone className="w-5 h-5 mr-2" />
                Atraer Prosperidad Ahora
              </Button>
            </div>
            <div className="flex justify-center">
              <Card className="p-8 bg-gradient-to-br from-green-500/10 to-yellow-500/10 border-green-500/20">
                <TrendingUp className="w-24 h-24 text-green-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-center mb-4">Éxito Financiero</h3>
                <p className="text-center text-muted-foreground">
                  Rituales especializados para atraer abundancia y oportunidades económicas
                </p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
              Transforma tu <span className="text-primary">Situación Financiera</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Los rituales de prosperidad trabajan con las energías universales de la abundancia para abrir caminos
              hacia el éxito económico.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-start space-x-3 p-4 rounded-lg bg-background border border-border">
                <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-muted-foreground">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">
            La <span className="text-primary">Abundancia</span> te Espera
          </h2>
          <p className="text-xl text-muted-foreground mb-8 text-pretty">
            No permitas que los bloqueos financieros limiten tu potencial. Abre los caminos hacia la prosperidad que
            siempre has deseado.
          </p>
          <Button size="lg" className="bg-accent hover:bg-accent/90">
            <Phone className="w-5 h-5 mr-2" />
            Iniciar Ritual de Prosperidad
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  )
}
