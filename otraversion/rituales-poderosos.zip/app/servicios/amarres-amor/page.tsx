import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, Clock, Star, Phone, CheckCircle, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function AmarresAmorPage() {
  const benefits = [
    "Recuperar a tu ex pareja de forma efectiva",
    "Fortalecer vínculos amorosos existentes",
    "Atraer el amor verdadero a tu vida",
    "Eliminar terceras personas definitivamente",
    "Crear conexiones emocionales profundas",
    "Despertar sentimientos dormidos",
  ]

  const process = [
    {
      step: "1",
      title: "Consulta Inicial",
      description: "Análisis detallado de tu situación amorosa y objetivos específicos",
    },
    {
      step: "2",
      title: "Preparación Ritual",
      description: "Selección de elementos personalizados y preparación del espacio sagrado",
    },
    {
      step: "3",
      title: "Ejecución del Amarre",
      description: "Realización del ritual con técnicas ancestrales y energías dirigidas",
    },
    {
      step: "4",
      title: "Seguimiento",
      description: "Monitoreo de resultados y ajustes necesarios para garantizar efectividad",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Breadcrumb */}
      <div className="py-4 px-4 sm:px-6 lg:px-8 border-b border-border">
        <div className="max-w-7xl mx-auto">
          <Link href="/servicios" className="inline-flex items-center text-muted-foreground hover:text-primary">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver a Servicios
          </Link>
        </div>
      </div>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-red-500/10 text-red-400 border-red-500/20">Servicio Especializado</Badge>
              <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
                <span className="text-primary">Amarres de</span>
                <br />
                <span className="text-red-400">Amor</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 text-pretty">
                Rituales poderosos diseñados para unir corazones y recuperar el amor perdido. Utilizando técnicas
                ancestrales y elementos naturales sagrados.
              </p>
              <div className="flex items-center space-x-4 mb-8">
                <Badge variant="secondary" className="text-accent text-lg px-4 py-2">
                  Desde $150 USD
                </Badge>
                <div className="flex items-center text-muted-foreground">
                  <Clock className="w-4 h-4 mr-2" />
                  <span>Resultados en 7-21 días</span>
                </div>
              </div>
              <Button size="lg" className="bg-accent hover:bg-accent/90">
                <Phone className="w-5 h-5 mr-2" />
                Solicitar Amarre Ahora
              </Button>
            </div>
            <div className="flex justify-center">
              <Card className="p-8 bg-gradient-to-br from-red-500/10 to-pink-500/10 border-red-500/20">
                <Heart className="w-24 h-24 text-red-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-center mb-4">Amor Garantizado</h3>
                <p className="text-center text-muted-foreground">
                  Más de 20 años de experiencia en rituales de amor con resultados comprobados
                </p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
              ¿Qué lograrás con los <span className="text-primary">Amarres de Amor</span>?
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Nuestros rituales de amor están diseñados para crear vínculos profundos y duraderos, trabajando con las
              energías universales del amor.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-start space-x-3 p-4 rounded-lg bg-background border border-border">
                <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-muted-foreground">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
              Proceso del <span className="text-primary">Ritual</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Cada amarre de amor sigue un proceso meticuloso y personalizado para garantizar los mejores resultados.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((item, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-primary-foreground font-bold">{item.step}</span>
                  </div>
                  <CardTitle className="text-lg">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{item.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-primary/5">
        <div className="max-w-4xl mx-auto">
          <Card className="p-8 text-center">
            <div className="flex justify-center mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 text-accent fill-current" />
              ))}
            </div>
            <blockquote className="text-xl italic text-muted-foreground mb-6">
              "Después de 6 meses separados, mi ex pareja regresó a mí gracias al amarre del Maestro Antonio. Ahora
              estamos más unidos que nunca y planeamos casarnos el próximo año."
            </blockquote>
            <cite className="text-primary font-semibold">- María González, Cliente Satisfecha</cite>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">
            ¿Listo para <span className="text-primary">Recuperar tu Amor</span>?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 text-pretty">
            No esperes más. Cada día que pasa es una oportunidad perdida. Contacta al Maestro Antonio y comienza tu
            camino hacia el amor que mereces.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-accent hover:bg-accent/90">
              <Phone className="w-5 h-5 mr-2" />
              Solicitar Amarre Ahora
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/contacto">Consulta Gratuita</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
