import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import Link from "next/link"
import { Star, Award, Users, Clock, Phone, MessageCircle, BookOpen, Globe, Heart } from "lucide-react"

export default function SobreAntonioPage() {
  const achievements = [
    {
      icon: Users,
      number: "5000+",
      label: "Clientes Satisfechos",
      description: "Miles de personas han transformado sus vidas",
    },
    {
      icon: Clock,
      number: "20+",
      label: "Años de Experiencia",
      description: "Más de dos décadas perfeccionando el arte",
    },
    {
      icon: Award,
      number: "95%",
      label: "Tasa de Éxito",
      description: "Resultados comprobados y garantizados",
    },
    {
      icon: Globe,
      number: "30+",
      label: "Países Atendidos",
      description: "Consultas presenciales y a distancia",
    },
  ]

  const specialties = [
    {
      icon: Heart,
      title: "Amarres de Amor",
      description: "Especialista en unir corazones y recuperar relaciones perdidas con técnicas ancestrales efectivas.",
    },
    {
      icon: Star,
      title: "Rituales de Prosperidad",
      description: "Experto en abrir caminos hacia la abundancia económica y el éxito financiero duradero.",
    },
    {
      icon: BookOpen,
      title: "Pactos Poderosos",
      description:
        "Maestro en la creación de pactos espirituales para lograr objetivos específicos y transformaciones profundas.",
    },
  ]

  const testimonials = [
    {
      name: "María González",
      location: "México",
      text: "Gracias al Maestro Antonio recuperé a mi esposo después de 8 meses separados. Su amarre de amor funcionó perfectamente y ahora somos más felices que nunca.",
      rating: 5,
    },
    {
      name: "Carlos Rodríguez",
      location: "Colombia",
      text: "Los rituales de prosperidad del Maestro Antonio cambiaron mi vida completamente. En 3 meses conseguí el trabajo de mis sueños y duplicé mis ingresos.",
      rating: 5,
    },
    {
      name: "Ana Martínez",
      location: "España",
      text: "Después de años de mala suerte, la protección espiritual del Maestro Antonio me liberó de todas las energías negativas. Ahora todo fluye perfectamente.",
      rating: 5,
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Maestro Reconocido</Badge>
              <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
                <span className="text-primary">Maestro</span>
                <br />
                <span className="text-foreground">Antonio Vasquez</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 text-pretty">
                Con más de 20 años dedicado al arte ancestral de la brujería y los rituales esotéricos, he ayudado a
                miles de personas a transformar sus vidas y encontrar la felicidad que merecen.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-accent hover:bg-accent/90">
                  <Phone className="w-5 h-5 mr-2" />
                  Consulta Personalizada
                </Button>
                <Button size="lg" variant="outline">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Contactar Ahora
                </Button>
              </div>
            </div>
            <div className="order-1 lg:order-2 flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-primary/20 rounded-full blur-3xl"></div>
                <Image
                  src="/antonio-profile.png"
                  alt="Maestro Antonio Vasquez"
                  width={500}
                  height={500}
                  className="relative rounded-2xl shadow-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
              Mi <span className="text-primary">Historia</span> y Camino Espiritual
            </h2>
            <p className="text-xl text-muted-foreground text-pretty">
              Descubre cómo comenzó mi viaje en el mundo de los rituales esotéricos y la transformación espiritual.
            </p>
          </div>

          <div className="prose prose-lg max-w-none text-muted-foreground">
            <p className="text-lg leading-relaxed mb-6">
              Mi nombre es Antonio Vasquez y durante más de 20 años me he dedicado al arte ancestral de la brujería y
              los rituales esotéricos. Mi camino comenzó desde muy joven, cuando descubrí mi don natural para conectar
              con las energías espirituales y ayudar a las personas a resolver sus problemas más profundos.
            </p>

            <p className="text-lg leading-relaxed mb-6">
              A lo largo de mi carrera, he estudiado diversas tradiciones esotéricas de diferentes culturas: desde la
              santería afrocubana hasta los rituales europeos antiguos, pasando por las prácticas chamánicas
              latinoamericanas. Esta formación multicultural me ha permitido desarrollar técnicas únicas y efectivas que
              se adaptan a las necesidades específicas de cada cliente.
            </p>

            <p className="text-lg leading-relaxed mb-6">
              Mi especialidad son los amarres de amor, rituales de prosperidad, pactos poderosos y trabajos de
              protección espiritual. He ayudado a miles de personas a recuperar a sus seres queridos, mejorar su
              situación económica, protegerse de energías negativas y encontrar su camino hacia la felicidad.
            </p>

            <p className="text-lg leading-relaxed">
              Cada ritual que realizo está respaldado por años de experiencia, conocimiento ancestral y un compromiso
              inquebrantable con el bienestar de mis clientes. Mi misión es ser el puente entre el mundo espiritual y
              las necesidades terrenales de quienes buscan mi ayuda.
            </p>
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
              Logros y <span className="text-primary">Reconocimientos</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Más de dos décadas de dedicación han resultado en miles de vidas transformadas y una reputación
              internacional sólida.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <Card key={index} className="text-center group hover:shadow-xl transition-all duration-300">
                <CardHeader>
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                    <achievement.icon className="w-8 h-8 text-primary" />
                  </div>
                  <CardTitle className="text-3xl font-bold text-primary">{achievement.number}</CardTitle>
                  <CardDescription className="font-semibold text-foreground">{achievement.label}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{achievement.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Specialties Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
              Mis <span className="text-primary">Especialidades</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Áreas de expertise donde he desarrollado técnicas únicas y efectivas a lo largo de mi carrera.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {specialties.map((specialty, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <specialty.icon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">
                    {specialty.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-muted-foreground">{specialty.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
              Lo que dicen mis <span className="text-primary">Clientes</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Testimonios reales de personas que han transformado sus vidas con mis rituales y servicios esotéricos.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-6">
                <CardContent className="p-0">
                  <div className="flex justify-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-accent fill-current" />
                    ))}
                  </div>
                  <blockquote className="text-muted-foreground italic mb-4 text-center">
                    "{testimonial.text}"
                  </blockquote>
                  <div className="text-center">
                    <cite className="text-primary font-semibold not-italic">{testimonial.name}</cite>
                    <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-primary/5">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">
            ¿Listo para <span className="text-primary">Transformar tu Vida</span>?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 text-pretty">
            Con más de 20 años de experiencia y miles de casos exitosos, estoy aquí para ayudarte a alcanzar tus
            objetivos y encontrar la felicidad que mereces.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-accent hover:bg-accent/90">
              <Phone className="w-5 h-5 mr-2" />
              Consulta Inmediata
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/contacto">Solicitar Información</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
