import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Phone, Mail, MessageCircle, Send, Shield } from "lucide-react"

export default function ContactoPage() {
  const contactMethods = [
    {
      icon: Phone,
      title: "Llamada Directa",
      description: "Consulta inmediata por teléfono",
      contact: "+1 (555) 123-4567",
      availability: "24/7 Disponible",
      color: "text-green-400",
    },
    {
      icon: MessageCircle,
      title: "WhatsApp",
      description: "Mensajes y consultas rápidas",
      contact: "+1 (555) 123-4567",
      availability: "Respuesta inmediata",
      color: "text-green-500",
    },
    {
      icon: Mail,
      title: "Email",
      description: "Consultas detalladas por correo",
      contact: "maestro@ritualespoderosos.com",
      availability: "Respuesta en 2-4 horas",
      color: "text-blue-400",
    },
  ]

  const services = [
    "Amarres de Amor",
    "Endulzamientos",
    "Rituales de Prosperidad",
    "Protección Espiritual",
    "Limpiezas y Desbloqueos",
    "Amarres Sexuales",
    "Consulta General",
    "Otro (especificar en mensaje)",
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Contacto Directo</Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
            <span className="text-primary">Contacta al</span>
            <br />
            <span className="text-foreground">Maestro Antonio</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto text-pretty">
            Estoy aquí para ayudarte a transformar tu vida. Contacta conmigo para una consulta personalizada y descubre
            cómo mis rituales pueden resolver tus problemas más profundos.
          </p>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {contactMethods.map((method, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 text-center">
                <CardHeader>
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                    <method.icon className={`w-8 h-8 ${method.color}`} />
                  </div>
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">{method.title}</CardTitle>
                  <CardDescription>{method.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="font-semibold text-foreground mb-2">{method.contact}</p>
                  <Badge variant="secondary" className="text-accent">
                    {method.availability}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
              Solicita tu <span className="text-primary">Consulta Personalizada</span>
            </h2>
            <p className="text-xl text-muted-foreground text-pretty">
              Completa el formulario y te contactaré en las próximas horas para analizar tu situación específica.
            </p>
          </div>

          <Card className="p-8">
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="nombre">Nombre Completo *</Label>
                  <Input id="nombre" placeholder="Tu nombre completo" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefono">Teléfono *</Label>
                  <Input id="telefono" type="tel" placeholder="+1 (555) 123-4567" required />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="tu@email.com" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="servicio">Servicio de Interés *</Label>
                <Select required>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona el servicio que necesitas" />
                  </SelectTrigger>
                  <SelectContent>
                    {services.map((service, index) => (
                      <SelectItem key={index} value={service.toLowerCase().replace(/\s+/g, "-")}>
                        {service}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="urgencia">Nivel de Urgencia</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="¿Qué tan urgente es tu situación?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="baja">Baja - Puedo esperar unos días</SelectItem>
                    <SelectItem value="media">Media - Necesito ayuda esta semana</SelectItem>
                    <SelectItem value="alta">Alta - Es muy urgente</SelectItem>
                    <SelectItem value="critica">Crítica - Necesito ayuda inmediata</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="mensaje">Describe tu Situación *</Label>
                <Textarea
                  id="mensaje"
                  placeholder="Cuéntame detalladamente tu situación. Mientras más información proporciones, mejor podré ayudarte..."
                  rows={6}
                  required
                />
              </div>

              <div className="flex items-start space-x-2">
                <input type="checkbox" id="privacidad" className="mt-1" required />
                <Label htmlFor="privacidad" className="text-sm text-muted-foreground">
                  Acepto que mis datos sean tratados con total confidencialidad y utilizados únicamente para brindarme
                  el servicio solicitado. *
                </Label>
              </div>

              <Button type="submit" size="lg" className="w-full bg-accent hover:bg-accent/90">
                <Send className="w-5 h-5 mr-2" />
                Enviar Consulta
              </Button>
            </form>
          </Card>
        </div>
      </section>

      {/* Privacy & Trust Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">
                <span className="text-primary">Confidencialidad</span> Garantizada
              </h2>
              <p className="text-lg text-muted-foreground mb-6 text-pretty">
                Entiendo que los temas que tratamos son muy personales y delicados. Por eso, garantizo total
                confidencialidad en todas nuestras consultas y rituales.
              </p>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start space-x-3">
                  <Shield className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span>Todas las consultas son completamente confidenciales</span>
                </li>
                <li className="flex items-start space-x-3">
                  <Shield className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span>Tus datos personales están protegidos y seguros</span>
                </li>
                <li className="flex items-start space-x-3">
                  <Shield className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span>Nunca comparto información de mis clientes</span>
                </li>
                <li className="flex items-start space-x-3">
                  <Shield className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span>Ambiente seguro y sin juicios para expresarte</span>
                </li>
              </ul>
            </div>
            <div className="flex justify-center">
              <Card className="p-8 bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20 text-center">
                <Shield className="w-24 h-24 text-primary mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-4">100% Confidencial</h3>
                <p className="text-muted-foreground">
                  Tu privacidad es mi prioridad. Todas las consultas se manejan con la máxima discreción y
                  profesionalismo.
                </p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
              Preguntas <span className="text-primary">Frecuentes</span>
            </h2>
            <p className="text-xl text-muted-foreground text-pretty">
              Respuestas a las dudas más comunes sobre mis servicios y consultas.
            </p>
          </div>

          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-3 text-primary">¿Cuánto tiempo toma ver resultados?</h3>
              <p className="text-muted-foreground">
                Los tiempos varían según el tipo de ritual y la complejidad de la situación. Los amarres de amor suelen
                mostrar resultados en 7-21 días, mientras que los rituales de prosperidad pueden tomar 15-30 días.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-3 text-primary">¿Realizas trabajos a distancia?</h3>
              <p className="text-muted-foreground">
                Sí, realizo rituales tanto presenciales como a distancia. La energía no conoce fronteras, y he ayudado
                exitosamente a clientes en más de 30 países alrededor del mundo.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-3 text-primary">¿Qué garantías ofreces?</h3>
              <p className="text-muted-foreground">
                Ofrezco garantía de satisfacción en todos mis trabajos. Si no ves resultados en el tiempo establecido,
                realizaré ajustes adicionales sin costo extra hasta lograr el objetivo deseado.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-3 text-primary">¿Cómo se realiza el pago?</h3>
              <p className="text-muted-foreground">
                Acepto diversos métodos de pago seguros: transferencias bancarias, PayPal, Western Union, y
                criptomonedas. El pago se divide en dos partes: 50% al inicio y 50% al completar el ritual.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Emergency Contact */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-primary/5">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">
            ¿Necesitas <span className="text-primary">Ayuda Urgente</span>?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 text-pretty">
            Para situaciones críticas que requieren atención inmediata, estoy disponible 24/7. No esperes más, tu
            bienestar es mi prioridad.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-green-600 hover:bg-green-700">
              <Phone className="w-5 h-5 mr-2" />
              Llamar Ahora: +1 (555) 123-4567
            </Button>
            <Button size="lg" className="bg-green-500 hover:bg-green-600">
              <MessageCircle className="w-5 h-5 mr-2" />
              WhatsApp Urgente
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
