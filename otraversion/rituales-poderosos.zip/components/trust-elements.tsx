import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Award, Clock, Users, CheckCircle, Star } from "lucide-react"

export function TrustElements() {
  const trustFactors = [
    {
      icon: Shield,
      title: "100% Confidencial",
      description: "Todas las consultas son completamente privadas y seguras",
      color: "text-blue-400",
    },
    {
      icon: Award,
      title: "Garantía de Resultados",
      description: "Si no ves resultados, realizamos ajustes sin costo adicional",
      color: "text-green-400",
    },
    {
      icon: Clock,
      title: "20+ Años de Experiencia",
      description: "Más de dos décadas perfeccionando rituales efectivos",
      color: "text-purple-400",
    },
    {
      icon: Users,
      title: "5000+ Clientes Felices",
      description: "Miles de vidas transformadas en todo el mundo",
      color: "text-orange-400",
    },
  ]

  const certifications = [
    "Maestro Certificado en Santería Afrocubana",
    "Especialista en Rituales Europeos Antiguos",
    "Practicante de Chamanismo Latinoamericano",
    "Experto en Protección Espiritual",
    "Consultor Esotérico Internacional",
  ]

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-accent/10 text-accent border-accent/20">Confianza y Credibilidad</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
            ¿Por qué <span className="text-primary">Confiar</span> en el Maestro Antonio?
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Más de 20 años de experiencia, miles de casos exitosos y un compromiso inquebrantable con la satisfacción de
            mis clientes.
          </p>
        </div>

        {/* Trust Factors Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {trustFactors.map((factor, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                  <factor.icon className={`w-8 h-8 ${factor.color}`} />
                </div>
                <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                  {factor.title}
                </h3>
                <p className="text-sm text-muted-foreground">{factor.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Certifications and Credentials */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-2xl font-bold mb-6 text-primary">Formación y Credenciales</h3>
            <div className="space-y-3">
              {certifications.map((cert, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-muted-foreground">{cert}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <Card className="p-6 bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20">
              <div className="flex items-center space-x-4 mb-4">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-accent fill-current" />
                  ))}
                </div>
                <Badge className="bg-accent text-accent-foreground">Calificación Promedio</Badge>
              </div>
              <p className="text-muted-foreground text-sm">
                "El Maestro Antonio es una persona íntegra y profesional. Sus rituales son efectivos y siempre mantiene
                la confidencialidad. Lo recomiendo completamente."
              </p>
              <p className="text-primary font-semibold text-sm mt-2">- Promedio de 5000+ reseñas</p>
            </Card>

            <Card className="p-6">
              <h4 className="font-semibold text-lg mb-3 text-primary">Disponibilidad Internacional</h4>
              <p className="text-muted-foreground text-sm mb-3">
                Atiendo clientes en más de 30 países con consultas presenciales y a distancia.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">México</Badge>
                <Badge variant="secondary">Colombia</Badge>
                <Badge variant="secondary">España</Badge>
                <Badge variant="secondary">Argentina</Badge>
                <Badge variant="secondary">Perú</Badge>
                <Badge variant="secondary">+25 más</Badge>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
