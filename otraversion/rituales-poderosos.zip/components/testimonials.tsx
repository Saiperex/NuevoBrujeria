import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Quote } from "lucide-react"

interface Testimonial {
  name: string
  location: string
  service: string
  text: string
  rating: number
  timeframe: string
}

const testimonials: Testimonial[] = [
  {
    name: "María González",
    location: "México City, México",
    service: "Amarre de Amor",
    text: "Después de 6 meses separados, mi ex pareja regresó a mí gracias al amarre del Maestro Antonio. Ahora estamos más unidos que nunca y planeamos casarnos el próximo año. Su trabajo es realmente efectivo.",
    rating: 5,
    timeframe: "Resultados en 15 días",
  },
  {
    name: "Carlos Rodríguez",
    location: "Bogotá, Colombia",
    service: "Ritual de Prosperidad",
    text: "Los rituales de prosperidad del Maestro Antonio cambiaron mi vida completamente. En 3 meses conseguí el trabajo de mis sueños y duplicé mis ingresos. La abundancia llegó de formas que nunca imaginé.",
    rating: 5,
    timeframe: "Resultados en 21 días",
  },
  {
    name: "Ana Martínez",
    location: "Madrid, España",
    service: "Protección Espiritual",
    text: "Después de años de mala suerte y energías negativas, la protección espiritual del Maestro Antonio me liberó completamente. Ahora todo fluye perfectamente en mi vida personal y profesional.",
    rating: 5,
    timeframe: "Efectos inmediatos",
  },
  {
    name: "Roberto Silva",
    location: "São Paulo, Brasil",
    service: "Limpieza Energética",
    text: "Sentía que mi vida estaba estancada en todos los aspectos. Después de la limpieza energética, se abrieron nuevas oportunidades laborales y mi relación familiar mejoró notablemente.",
    rating: 5,
    timeframe: "Resultados en 7 días",
  },
  {
    name: "Isabella Torres",
    location: "Buenos Aires, Argentina",
    service: "Endulzamiento",
    text: "Mi matrimonio estaba al borde del divorcio por constantes peleas. El endulzamiento del Maestro Antonio trajo paz y armonía a nuestro hogar. Ahora somos una familia feliz nuevamente.",
    rating: 5,
    timeframe: "Resultados en 10 días",
  },
  {
    name: "Miguel Herrera",
    location: "Lima, Perú",
    service: "Amarre Sexual",
    text: "La pasión había desaparecido de mi relación de 8 años. Gracias al trabajo del Maestro Antonio, recuperamos la intimidad y el deseo mutuo. Nuestra conexión es más fuerte que nunca.",
    rating: 5,
    timeframe: "Resultados en 12 días",
  },
]

export function TestimonialsSection() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Testimonios Reales</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
            Historias de <span className="text-primary">Transformación</span> Real
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Miles de personas han cambiado sus vidas con los rituales del Maestro Antonio. Estas son algunas de sus
            historias de éxito.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 h-full">
              <CardContent className="p-6 flex flex-col h-full">
                <div className="flex items-center justify-between mb-4">
                  <Badge variant="secondary" className="text-accent text-xs">
                    {testimonial.service}
                  </Badge>
                  <div className="flex">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-accent fill-current" />
                    ))}
                  </div>
                </div>

                <div className="flex-1 mb-4">
                  <Quote className="w-6 h-6 text-primary/50 mb-2" />
                  <blockquote className="text-muted-foreground italic text-sm leading-relaxed">
                    "{testimonial.text}"
                  </blockquote>
                </div>

                <div className="border-t border-border pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <cite className="text-primary font-semibold not-italic text-sm">{testimonial.name}</cite>
                      <p className="text-xs text-muted-foreground">{testimonial.location}</p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {testimonial.timeframe}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4">
            Únete a los miles de clientes satisfechos que han transformado sus vidas
          </p>
          <div className="flex items-center justify-center space-x-6 text-sm text-muted-foreground">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span>5000+ Clientes Satisfechos</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              <span>95% Tasa de Éxito</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-primary rounded-full"></div>
              <span>20+ Años de Experiencia</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
