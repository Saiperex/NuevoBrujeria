// Mobile Navigation
const hamburger = document.querySelector(".hamburger")
const navMenu = document.querySelector(".nav-menu")

if (hamburger && navMenu) {
  hamburger.addEventListener("click", () => {
    hamburger.classList.toggle("active")
    navMenu.classList.toggle("active")
  })

  // Close mobile menu when clicking on a link
  document.querySelectorAll(".nav-menu a").forEach((link) => {
    link.addEventListener("click", () => {
      hamburger.classList.remove("active")
      navMenu.classList.remove("active")
    })
  })
}

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))
    if (target) {
      target.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  })
})

// Header background on scroll
window.addEventListener("scroll", () => {
  const header = document.querySelector(".header")
  if (header) {
    if (window.scrollY > 100) {
      header.style.background = "rgba(17, 24, 39, 0.98)"
    } else {
      header.style.background = "rgba(17, 24, 39, 0.95)"
    }
  }
})

const fadeInObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible")
        // Una vez que el elemento es visible, dejamos de observarlo para mejor performance
        fadeInObserver.unobserve(entry.target)
      }
    })
  },
  {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  },
)

function initializeFadeInAnimations() {
  // Elementos del hero
  const heroTitle = document.querySelector(".hero-text h1")
  const heroSubtitle = document.querySelector(".hero-text h2")
  const heroDescription = document.querySelector(".hero-text p")
  const heroButtons = document.querySelector(".hero-buttons")
  const maestroImage = document.querySelector(".maestro-image")

  if (heroTitle) {
    heroTitle.classList.add("fade-in-left")
    fadeInObserver.observe(heroTitle)
  }

  if (heroSubtitle) {
    heroSubtitle.classList.add("fade-in-left", "fade-in-delay-1")
    fadeInObserver.observe(heroSubtitle)
  }

  if (heroDescription) {
    heroDescription.classList.add("fade-in-left", "fade-in-delay-2")
    fadeInObserver.observe(heroDescription)
  }

  if (heroButtons) {
    heroButtons.classList.add("fade-in-left", "fade-in-delay-3")
    fadeInObserver.observe(heroButtons)
  }

  if (maestroImage) {
    maestroImage.classList.add("fade-in-right", "fade-in-delay-2")
    fadeInObserver.observe(maestroImage)
  }

  // Títulos de sección
  document.querySelectorAll(".section-title").forEach((title, index) => {
    title.classList.add("fade-in-up")
    fadeInObserver.observe(title)
  })

  // Tarjetas de servicios con animación escalonada
  document.querySelectorAll(".service-card").forEach((card, index) => {
    card.classList.add("fade-in-up", `fade-in-delay-${(index % 3) + 1}`)
    fadeInObserver.observe(card)
  })

  // Estadísticas
  document.querySelectorAll(".stat").forEach((stat, index) => {
    stat.classList.add("fade-in-up", `fade-in-delay-${index + 1}`)
    fadeInObserver.observe(stat)
  })

  // Contenido de testimonios
  document.querySelectorAll(".testimonial-content").forEach((content) => {
    content.classList.add("fade-in-up")
    fadeInObserver.observe(content)
  })

  // Información de contacto
  const contactInfo = document.querySelector(".contact-info")
  const contactForm = document.querySelector(".contact-form")

  if (contactInfo) {
    contactInfo.classList.add("fade-in-left")
    fadeInObserver.observe(contactInfo)
  }

  if (contactForm) {
    contactForm.classList.add("fade-in-right", "fade-in-delay-2")
    fadeInObserver.observe(contactForm)
  }

  // Métodos de contacto
  document.querySelectorAll(".contact-method").forEach((method, index) => {
    method.classList.add("fade-in-left", `fade-in-delay-${index + 1}`)
    fadeInObserver.observe(method)
  })
}

// Testimonials Slider
let currentTestimonial = 0
const testimonials = document.querySelectorAll(".testimonial")
const totalTestimonials = testimonials.length

function showTestimonial(index) {
  testimonials.forEach((testimonial) => {
    testimonial.classList.remove("active")
  })
  if (testimonials[index]) {
    testimonials[index].classList.add("active")
  }
}

function nextTestimonial() {
  currentTestimonial = (currentTestimonial + 1) % totalTestimonials
  showTestimonial(currentTestimonial)
}

function prevTestimonial() {
  currentTestimonial = (currentTestimonial - 1 + totalTestimonials) % totalTestimonials
  showTestimonial(currentTestimonial)
}

// Testimonial controls
const nextBtn = document.querySelector(".next-btn")
const prevBtn = document.querySelector(".prev-btn")

if (nextBtn) nextBtn.addEventListener("click", nextTestimonial)
if (prevBtn) prevBtn.addEventListener("click", prevTestimonial)

// Auto-advance testimonials
if (totalTestimonials > 0) {
  setInterval(nextTestimonial, 5000)
}

document.querySelectorAll(".service-card").forEach((card) => {
  card.addEventListener("mouseenter", function () {
    this.style.transform = "translateY(-10px) scale(1.02)"
  })

  card.addEventListener("mouseleave", function () {
    this.style.transform = "translateY(0) scale(1)"
  })
})

// Contact form handling
const contactForm = document.getElementById("contactForm")
if (contactForm) {
  contactForm.addEventListener("submit", function (e) {
    e.preventDefault()

    // Get form data
    const formData = new FormData(this)
    const data = Object.fromEntries(formData)

    // Simple validation
    if (!data.nombre || !data.email || !data.telefono || !data.servicio || !data.mensaje) {
      alert("Por favor, completa todos los campos.")
      return
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(data.email)) {
      alert("Por favor, ingresa un email válido.")
      return
    }

    // Show success message
    alert("¡Gracias por tu consulta! Te contactaré pronto para ayudarte.")

    // Reset form
    this.reset()

    // In a real implementation, you would send this data to a server
    console.log("Form data:", data)
  })
}

function addLoadingStates() {
  const buttons = document.querySelectorAll(".btn-primary, .btn-secondary")

  buttons.forEach((button) => {
    button.addEventListener("click", function (e) {
      if (this.type === "submit" || this.classList.contains("submit-btn")) {
        e.preventDefault()

        const originalText = this.textContent
        this.textContent = "Enviando..."
        this.style.opacity = "0.7"
        this.style.pointerEvents = "none"

        setTimeout(() => {
          this.textContent = originalText
          this.style.opacity = "1"
          this.style.pointerEvents = "auto"
        }, 2000)
      }
    })
  })
}

function handleResponsiveChanges() {
  let resizeTimeout

  window.addEventListener("resize", () => {
    clearTimeout(resizeTimeout)
    resizeTimeout = setTimeout(() => {
      // Recalcular animaciones si es necesario
      const isMobile = window.innerWidth <= 768

      // Ajustar navegación móvil
      if (!isMobile && navMenu) {
        navMenu.classList.remove("active")
        if (hamburger) hamburger.classList.remove("active")
      }

      // Reinicializar slider de testimonios si es necesario
      if (testimonials.length > 0) {
        showTestimonial(currentTestimonial)
      }
    }, 250)
  })

  // Manejar cambios de orientación
  window.addEventListener("orientationchange", () => {
    setTimeout(() => {
      // Forzar recálculo de layout después del cambio de orientación
      window.dispatchEvent(new Event("resize"))
    }, 100)
  })
}

function initializeWebsite() {
  // Inicializar animaciones fade-in
  initializeFadeInAnimations()

  // Inicializar estados de carga
  addLoadingStates()

  // Inicializar manejo responsive
  handleResponsiveChanges()

  // Mostrar primer testimonio si existe
  if (testimonials.length > 0) {
    showTestimonial(0)
  }

  console.log("%c🌟 Rituales y Pactos Poderosos 🌟", "color: #8B5CF6; font-size: 20px; font-weight: bold;")
  console.log("%cMaestro Antonio Vasquez - Brujo Especialista", "color: #F59E0B; font-size: 14px;")
  console.log("%cSitio web con animaciones fade-in y diseño responsive", "color: #EC4899; font-size: 12px;")
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeWebsite)
} else {
  initializeWebsite()
}

function preloadCriticalImages() {
  const criticalImages = ["images/inicio.webp", "images/perfil.png", "images/logo.png"]

  criticalImages.forEach((src) => {
    const img = new Image()
    img.src = src
  })
}

// Precargar imágenes críticas
preloadCriticalImages()
